# One Dark
Syntax Theme For MonoDevelop/Unity, based off of the One Dark theme for Atom.

Original: https://github.com/atom/one-dark-ui
